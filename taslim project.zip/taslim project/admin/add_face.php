<?php

    include '../assets/php/init.php';
    include '../assets/php/processes/admin/LoadEmployeeData.php';
    // print_r($Generic -> verify_emp_ID('emp-001'));
    $section = '
        <div class="py-4 px-3 h-100 flex-v">
            <div class="p-3 text-muted">
                <h4 class="bold text-capitalize theme-color">' . ((isset($_GET["action"])) ? "edit face" : "add face") . '</h4>
            </div>
            <div class = "flex-1 overflow-y-auto">
                <form class="p-4 bg-white row m-0 shadow-sm border-radius-20px " method = "POST" action = "add_product.php' . ((isset($_GET["action"]) && $_GET["action"] == "edit_product") ? "?action_type=update&product_id=" . $_GET["product_id"] : "") . '" enctype = "multipart/form-data">
                    <div class = "col-12 mb-3">
                        <span class = "bold">Employee ID *</span>
                        <input value = "' . ((isset($LoadProductData -> product_data["name"])) ? $LoadProductData -> product_data["name"] : ((isset($_POST["product_name"])) ? $_POST["product_name"] : "")) . '" name = "emp_ID" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                    </div>
                    <div class = "col-12 mb-3">
                        <span class = "bold">Image</span>
                        <div class = "border my-2 rounded">
                            <div>
                                <img src = "' . ((isset($LoadProductData -> product_data["image"])) ? ((file_exists("../assets/" . $LoadProductData -> product_data["image"])) ? "../assets/" . $LoadProductData -> product_data["image"] : "../assets/img/corrupt_img.png") : "../assets/img/corrupt_img.png") . '" id = "preview_img" style = "max-height: 180px;" class = "my-2 outline-0 d-block mx-auto resize-0" />
                            </div>
                            <label for = "product-image" class = "bg-light m-0 text-c d-block w-100 p-3 cursor-pointer bold text-capitalize text-secondary border-top">
                                click to select image
                                <input name = "face_img" accept = "image/*" type = "file" id = "product-image" hidden/>
                            </label>
                        </div>
                    </div>
                    <div class = "my-3 p-3 col-12">
                        <input type = "submit" name = "add_face" class = "p-3 text-capitalize disabled d-block w-100 theme-bg border-0 rounded shadow text-c bold text-white" value = "' . ((isset($_GET["action"])) ? "save changes" : "add face") . '"/>
                    </div>
                </form>
            </div>

        </div>

        <script src = "../assets/js/admin/add_face.js"></script>
    ';

    include "template/template.php";

?>
