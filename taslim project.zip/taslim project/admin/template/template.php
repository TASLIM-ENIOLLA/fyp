<?php

    if(!isset(json_decode($_COOKIE["ACS"]) -> id) || json_decode($_COOKIE["ACS"]) -> user != "admin"){
        header("Location: ../");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>P.E.A.</title>
    <link rel="stylesheet" href="../assets/css/styles/index.css">
    <script src="../assets/js/vendors/toast.js" charset="utf-8"></script>
</head>
<body>
    <section class="vh100 vw100 flex-h overflow-0 bg-white">
        <section id = "mobile-menu" class="col-0 bg-light m-0 p-0 col-sm-0 overflow-x-0 overflow-y-auto transit">
            <!-- paste programmatically from main menu -->
        </section>
        <section id = "main-section" class="col-12 p-0 m-0 flex-v">
            <header class="border-bottom border-grey">
                <div class="p-3 po-rel theme-bg text-white flex-h j-c-c a-i-c" style="height: 65px;">
                    <div class = "flex-h a-i-c flex-1">
                        <span id = "mobile-menu-toggle" class="icon-bars cursor-pointer fa-2x bold mr-3 col-sm-d-none"></span>
                        <div class="flex-1 flex-h">
                            <div class="flex-1 single-line">
                                <a class="text-uppercase text-white bold">access control system</a>
                            </div>
                        </div>
                    </div>
                    <div>
                        <?php
                            if(isset($_COOKIE["ACS"]) && isset(json_decode($_COOKIE["ACS"]) -> id) && json_decode($_COOKIE["ACS"]) -> user == "admin"){
                                echo '
                                    <a href="logout.php" title = "Logout" class = "flicker after-property-rotate fa fa-power-off text-white cursor-pointer mx-3" style = "font-size: 19px;"></a>
                                ';
                            }
                            else{
                                echo '
                                    <a href="login.php" title = "Login" class = "flicker icon-user text-white cursor-pointer fa-2x mx-3"></a>
                                ';
                            }
                        ?>
                    </div>
                    <div class="w-100 shadow po-abs d-none" style="bottom: 0px; padding: 0px; left: 0;">
                        <div class="bg-warning transit" id = "loader" style="height: 3px; width: 1%;">

                        </div>
                    </div>
                </div>
            </header>
            <section class="flex-1 overflow-y-auto bg-light flex-h">
                <section id = "main-menu" class = "h-100 col-0 col-sm-200px overflow-y-auto">
                    <div class="px-3 py-4 menu-item-list border-bottom">
                        <a title = "dashboard" href = "index.php" data-active-link class="flex-h a-i-c my-4 py-2 px-3 cursor-pointer">
                            <span class="fa fa-dashboard mr-4" style="font-size: 1.4rem;"></span>
                            <div class="flex-1 flex-h">
                                <span class="single-line flex-1 text-capitalize bold letter-spacing-1">dashboard</span>
                            </div>
                        </a>
                        <a title = "registered faces" href = "registered_faces.php" class="flex-h a-i-c my-4 py-2 px-3 cursor-pointer">
                            <span class="fa fa-id-badge mr-4" style="font-size: 1.4rem;"></span>
                            <div class="flex-1 flex-h">
                                <span class="single-line flex-1 text-capitalize bold letter-spacing-1">registered faces</span>
                            </div>
                        </a>
                        <a title = "add face" href = "add_face.php" class="flex-h a-i-c my-4 py-2 px-3 cursor-pointer">
                            <span class="fa fa-plus-square mr-4" style="font-size: 1.4rem;"></span>
                            <div class="flex-1 flex-h">
                                <span class="single-line flex-1 text-capitalize bold letter-spacing-1">add face</span>
                            </div>
                        </a>
                        <a title = "access log" href = "access_log.php" class="flex-h a-i-c my-4 py-2 px-3 cursor-pointer">
                            <span class="fa fa-bars mr-4" style="font-size: 1.4rem;"></span>
                            <div class="flex-1 flex-h">
                                <span class="single-line flex-1 text-capitalize bold letter-spacing-1">access log</span>
                            </div>
                        </a>
                        <a title = "admin profile" href = "admin_profile.php" class="flex-h a-i-c my-4 py-2 px-3 cursor-pointer">
                            <span class="fa fa-user mr-4" style="font-size: 1.4rem;"></span>
                            <div class="flex-1 flex-h">
                                <span class="single-line flex-1 text-capitalize bold letter-spacing-1">admin profile</span>
                            </div>
                        </a>
                        <a title = "logout" href = "logout.php" class="flex-h a-i-c my-4 py-2 px-3 cursor-pointer">
                            <span class="fa fa-power-off mr-4" style="font-size: 1.4rem;"></span>
                            <div class="flex-1 flex-h">
                                <span class="single-line flex-1 text-capitalize bold letter-spacing-1">logout</span>
                            </div>
                        </a>
                    </div>
                    <div class="px-3 py-4 menu-item-list border-bottom">
                        <a title = "monitor" href = "monitor.php" data-active-link class="flex-h a-i-c my-4 py-2 px-3 cursor-pointer">
                            <span class="fa fa-desktop mr-4" style="font-size: 1.4rem;"></span>
                            <div class="flex-1 flex-h">
                                <span class="single-line flex-1 text-capitalize bold letter-spacing-1">monitor</span>
                            </div>
                        </a>
                    </div>
                </section>
                <section id = "main-content" class = "h-100 flex-1 p-0 overflow-y-auto po-rel">
                    <!-- content here -->
                    <?= ((isset($section)) ? $section : "") ?>
                </section>
            </section>
        </section>
    </section>

    <script src="../assets/js/admin/index.js" charset="utf-8"></script>
</body>
</html>
