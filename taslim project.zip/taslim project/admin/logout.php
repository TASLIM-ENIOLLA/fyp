<?php

    include '../assets/php/processes/admin/Logout.php';

    $section = '
        <div class="py-4 px-3">
            <div class="p-3 theme-color">
                <h4 class="bold text-capitalize">Logout</h4>
            </div>
            <form target = "" method = "POST" class = "p-5 bg-white shadow-sm border-radius-20px">
                <div class = "rounded border px-3 py-4">
                    <div class = "bold text-muted">
                        Are you sure you want to logout?
                    </div>
                </div>
                <div class = "col-md-4 py-2 px-0 mt-3">
                    <input name = "logout" type = "submit" value = "logout" class = "bg-danger py-2 px-4 rounded border-0 text-white bold text-capitalize shadow" />
                    <input name = "cancel" type = "submit" value = "cancel" class = "py-2 px-4 rounded border-0 text-secondary bold text-capitalize bg-clear" />
                </div>
            </form>
        </div>
    ';

    include "template/template.php";

?>
