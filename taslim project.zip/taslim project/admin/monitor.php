<?php

    include "../assets/php/init.php";

    $section = '
        <div class="py-4 px-3 h-100 overflow-y-auto">
            <div>
                <div class="p-3 theme-color">
                    <h4 class="bold text-capitalize">Monitor</h4>
                </div>
                <div class = "mb-5">
                    <div class="p-4 bg-white flex-wrap text-muted overflow-y-auto border border-radius-20px shadow-sm">
                        <div class = "py-4 text-c text-secondary transit" id = "caption-area">
                            <div>
                                <span class = "fa fa-camera fa-4x"></span>
                            </div>
                            <div class = "pt-3">
                                <span class = "text-capitalize bold" id = "caption-text">webcam feed not available</span>
                            </div>
                            <div class = "pt-4">
                                <div class = "py-2 px-5 d-inline-block border-0 shadow text-capitalize text-white rounded btn-secondary bold cursor-pointer" id = "webcam-activator">activate webcam feed</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div>
                <div class="p-3 theme-color">
                    <h4 class="bold text-capitalize">Train dataset</h4>
                </div>
                <div class = "mb-5">
                    <div class="p-4 bg-white flex-wrap text-muted overflow-y-auto border border-radius-20px shadow-sm">
                        <div class = "py-4 text-secondary transit">
                            <div class = "pt-3">
                                <span class = "text-capitalize bold" id = "caption-text">Last dataset training: ' . (
                                    (json_decode($_COOKIE["ACS"]) -> last_dataset_training_timestamp == NULL)
                                    ? "--:--:--"
                                    : date("d/m/Y h:i:s", strtotime(json_decode($_COOKIE["ACS"]) -> last_dataset_training_timestamp))
                                ) . '</span>
                            </div>
                            <div class = "pt-3 col-md-8 px-0">
                                <span class = "text-warning bold">This process is quite exhaustive and may take a while to be completed, depending on the capablity of this machine. Please proceed only when you are certain.</span>
                            </div>
                            <div class = "pt-4">
                                <div class = "py-2 px-3 d-inline-block border-0 shadow text-capitalize text-white rounded btn-secondary bold cursor-pointer" id = "train-dataset">train dataset</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src = "../assets/js/admin/monitor.js"></script>
    ';

    include "template/template.php";

?>
