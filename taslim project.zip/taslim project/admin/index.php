<?php

    include "../assets/php/init.php";
    include "../assets/php/processes/admin/LoadAdminData.php";
    include "../assets/php/processes/admin/UpdateFaceImagesTable.php";
    include "../assets/php/processes/admin/UpdateEmployeeJSONFile.php";

    $section = '
        <div class="py-4 px-3 h-100 flex-v">
            <div class="p-3 theme-color">
                <h4 class="bold text-capitalize">Welcome ' . ADMIN["f_name"] . '</h4>
            </div>
            <div class = "flex-1 overflow-y-auto">
                <div class="flex-h w-100 flex-wrap text-muted p-4 bg-white border-radius-20px shadow-sm">
                    <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                        <a title = "registered faces" href="registered_faces.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                            <div class="px-3">
                                <span class="fa fa-2x fa-id-badge"></span>
                            </div>
                            <div class="flex-h flex-1">
                                <span class="flex-1 single-line text-capitalize bold">registered faces</span>
                            </div>
                        </a>
                    </div>
                    <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                        <a title = "add face" href="add_face.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                            <div class="px-3">
                                <span class="fa fa-2x fa-plus-square"></span>
                            </div>
                            <div class="flex-h flex-1">
                                <span class="flex-1 single-line text-capitalize bold">add face</span>
                            </div>
                        </a>
                    </div>
                    <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                        <a title = "access log" href="access_log.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                            <div class="px-3">
                                <span class="fa fa-2x fa-bars"></span>
                            </div>
                            <div class="flex-h flex-1">
                                <span class="flex-1 single-line text-capitalize bold">Access log</span>
                            </div>
                        </a>
                    </div>
                    <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                        <a title = "admin profile" href="admin_profile.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                            <div class="px-3">
                                <span class="fa fa-2x fa-user"></span>
                            </div>
                            <div class="flex-h flex-1">
                                <span class="flex-1 single-line text-capitalize bold">admin profile</span>
                            </div>
                        </a>
                    </div>
                    <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                        <a title = "monitor" href="monitor.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg bg-light shadow flex-h a-i-c">
                            <div class="px-3">
                                <span class="fa fa-2x fa-desktop"></span>
                            </div>
                            <div class="flex-h flex-1">
                                <span class="flex-1 single-line text-capitalize bold">monitor</span>
                            </div>
                        </a>
                    </div>
                    <div class = "col-12 col-sm-6 col-md-4 col-lg-3 py-3">
                        <a title = "logout" href="logout.php" style = "min-height: 70px;" class="p-3 theme-color rounded-lg text-danger bg-light shadow flex-h a-i-c">
                            <div class="px-3">
                                <span class="fa fa-2x fa-power-off"></span>
                            </div>
                            <div class="flex-h flex-1">
                                <span class="flex-1 single-line text-capitalize bold">logout</span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    ';

    include "template/template.php";

?>
