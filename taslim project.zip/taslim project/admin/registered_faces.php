<?php

    include '../assets/php/init.php';
    include '../assets/php/processes/admin/LoadRegisteredFaces.php';


    $section = '
        <div class="py-4 px-3 flex-v h-100">
            <div class="p-3 text-muted flex-h">
                <div class="flex-1 flex-h">
                    <h4 class="bold text-capitalize flex-1 single-line theme-color">Registered faces</h4>
                </div>' .
                (($LoadRegisteredFaces -> row_length > 0 && !isset($_GET["emp_ID"])) ? '
                    <div class="px-2">
                        <label for = "delete_faces" title = "Delete faces" class = "p-2 fa fa-trash text-danger cursor-pointer flicker" style="transform: scale(1.5);">
                            <input type = "submit" hidden id = "delete_faces"/>
                        </label>
                    </div>
                ' : "") . '
            </div>
            <div class="px-3 m-0 flex-1 overflow-y-auto">
                <div class = "p-4 bg-white border-radius-20px shadow-sm my-3">
                    ' . (
                        (!isset($_GET["emp_ID"]))
                        ? $LoadRegisteredFaces -> render()
                        : $LoadRegisteredFaces -> load_employee_data()
                    ) . '
                </div>
            </div>
        </div>

        <script src = "../assets/js/admin/all_faces.js"></script>
    ';

    include "template/template.php";

?>
