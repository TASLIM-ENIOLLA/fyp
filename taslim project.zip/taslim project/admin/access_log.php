<?php

    include "../assets/php/init.php";
    include "../assets/php/processes/admin/LoadAccessLog.php";

    $section = '
        <div class="py-4 px-3 h-100 flex-v">
            <div class="p-3 theme-color">
                <h4 class="bold text-capitalize">Access log</h4>
            </div>
            <div class = "p-3 flex-1 overflow-y-auto">
                <div class="p-4 bg-white row m-0 shadow-sm border-radius-20px">
                    ' . $LoadAccessLog -> render() . '
                </div>
            </div>
        </div>

        <script src="../assets/js/admin/access_log.js"></script>
    ';

    include "template/template.php";

?>
