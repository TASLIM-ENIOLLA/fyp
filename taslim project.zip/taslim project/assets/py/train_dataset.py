import os
import json
import cv2 as cv
import numpy as np

haar_cascade = cv.CascadeClassifier("haarclassifiers/haarcascade_frontalface_default.xml")
DIR = r"../img/employee/faces/"
faces_folder_list = []
features = []
labels = []

for folder in os.listdir(DIR):
    faces_folder_list.append(folder)
    print(folder)


def resizeImage(image):
    width = 350
    height = 450

    dimensions = (width, height)

    return cv.resize(image, dimensions, interpolation = cv.INTER_AREA)


def creater_trainer():
    for employee in faces_folder_list:
        path = os.path.join(DIR, employee)
        label = employee.index(employee)

        for img in os.listdir(path):
            img_path = os.path.join(path, img)

            img_array = cv.imread(img_path)
            image = cv.cvtColor(img_array, cv.COLOR_BGR2GRAY)
            image = resizeImage(image)


            faces_rect = haar_cascade.detectMultiScale(image, scaleFactor = 1.1)

            for (x, y, w, h) in faces_rect:
                faces_roi = image[
                    y: y + h,
                    x: x + h
                ]
                print(faces_roi)
                features.append(faces_roi)
                labels.append(label)

creater_trainer()

features = np.array(features, dtype = "object")
labels = np.array(labels)

face_recognizer = cv.face.EigenFaceRecognizer_create();
face_recognizer.train(features, labels)
face_recognizer.save("saves/face_trained.yml")

np.save("saves/features.npy", features)
np.save("saves/labels.npy", labels)

# employee = json.loads(open("../json/employee.json", "r").read());
# print("Number of features = " + features)
# print("Number of labels = " + labels)
