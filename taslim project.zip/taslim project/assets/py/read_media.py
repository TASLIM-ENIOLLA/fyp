import os
import cv2 as cv
import numpy as np

def rescaleFrame(frame, scale = .75):
    width = int(frame.shape[1] * scale)
    height = int(frame.shape[0] * scale)

    dimensions = (width, height)

    return cv.resize(frame, dimensions, interpolation = cv.INTER_AREA)

def changeScale(capture, width, height):
    # Live Video
    capture.set(3, width)
    capture.set(4, height)

def drawBlankImage():
    blank = np.zeros((500, 500), "uint8")
    cv.imshow("Blank", blank)

def flipCaptureHorizontally(capture):
    return cv.flip(capture, 1)

def convertCapture2Gray(capture):
    return cv.cvtColor(capture, cv.COLOR_BGR2GRAY)

def convertCapture2CannyImage(capture):
    return cv.Canny(capture, 1, 2)

def blurCapture(capture):
    return cv.GaussianBlur(capture, (5, 5), cv.BORDER_DEFAULT)

def readVideoFromWebcam():
    video = cv.VideoCapture(0)
    changeScale(video, 400, 400)

    while True:
        isTrue, frame = video.read()

        # frame = convertCapture2Gray(frame)
        frame = flipCaptureHorizontally(frame)

        haar_cascade = cv.CascadeClassifier("haarclassifiers/haarcascade_frontalface_default.xml")

        faces_rect = haar_cascade.detectMultiScale(frame, scaleFactor = 1.1, minNeighbors = 3)

        no_of_faces = len(faces_rect);

        frame = cv.putText(
            frame,
            f'Number of faces found = {no_of_faces}',
            (10, 20),
            cv.FONT_HERSHEY_TRIPLEX,
            .35,
            (0, 255, 0),
            1
        )

        if(no_of_faces == 1):
            frame = cv.putText(
                frame,
                'VERIFYING...',
                (10, 40),
                cv.FONT_HERSHEY_TRIPLEX,
                .35,
                (255, 255, 0),
                1
            )
        elif(no_of_faces > 1):
            frame = cv.putText(
                frame,
                'ONE FACE AT A TIME',
                (10, 40),
                cv.FONT_HERSHEY_TRIPLEX,
                .35,
                (0, 255, 255),
                1
            )
        else:
            frame = cv.putText(
                frame,
                'IDLE MODE',
                (10, 40),
                cv.FONT_HERSHEY_TRIPLEX,
                .35,
                (0, 255, 255),
                1
            )

        for (x, y, w, h) in faces_rect:
            cv.rectangle(
                frame,
                (x, y),
                (x + w, y + h),
                (0, 255, 0),
                thickness = 2
            );
        # frame = convertCapture2Gray(frame)
        cv.imshow("WebCam Stream", frame)

        if cv.waitKey(20) & 0xFF == ord("x"):
            break

    video.release()
    cv.destroyAllWindows()

readVideoFromWebcam()
