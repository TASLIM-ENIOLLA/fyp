import os
import json
import cv2 as cv
import numpy as np

haar_cascade = cv.CascadeClassifier("haarclassifiers/haarcascade_frontalface_default.xml")
tmp_folder_path = "../img/tmp/";
face_count = 0

for img in os.listdir(tmp_folder_path):
    img_path = os.path.join(tmp_folder_path, img)

    image = cv.imread(img_path)

    faces_rect = haar_cascade.detectMultiScale(image, scaleFactor = 1.1, minNeighbors = 3)
    no_of_faces = len(faces_rect)

    if no_of_faces > 0:
        face_count += 1

print(face_count)
