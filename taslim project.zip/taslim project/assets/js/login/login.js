document.querySelector("#submit-login").addEventListener(
    "click",
    (e) => {
        let user_id = document.querySelector("#login #user_id").value;
        let password = document.querySelector("#login #password").value;
        let login_credentials = {
            "email" : user_id,
            "password" : password
        };
        login_credentials = JSON.stringify(login_credentials);

        let xmlHtttp = new XMLHttpRequest();
        xmlHtttp.onreadystatechange = function(){
            if(this.readyState == 4 && this.status == 200){
                let responseText = this.responseText;
                console.log(responseText)

                if(responseText != "error" && responseText != "failed"){
                    if(responseText == "admin"){
                        toast("Login successful. Getting things ready...", "light", 2000).then(
                            e => window.location.replace("../admin/index.php")
                        );
                    }
                }
                else if(responseText == "failed"){
                    toast("Login credentials seem incorrect.");
                }
                else if(responseText == "error"){
                    toast("An error occured, please try again.");
                }
            }
        };
        xmlHtttp.open(
            "POST",
            "../assets/php/processes/login/login.php",
            true
        );
        xmlHtttp.setRequestHeader(
            "Content-type",
            "application/x-www-form-urlencoded"
        );
        xmlHtttp.send("login_credentials=" + login_credentials);
    }
);
