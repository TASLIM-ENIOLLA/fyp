class Category{
    constructor(){
        document.querySelector("#select_all").onclick = (e) => {
            if(e.srcElement.classList.contains("fa-check-square-o")){
                e.srcElement.classList.replace("fa-check-square-o", "fa-check-square")
                this.select_all_categories();
            }
            else{
                e.srcElement.classList.replace("fa-check-square", "fa-check-square-o")
                this.deselect_all_categories();
            }
        }

        document.querySelectorAll(".category-checkbox").forEach(
            item => {
                item.onchange = (e) => {

                    if(e.srcElement.getAttribute("data-checked") == "true"){
                        e.srcElement.setAttribute("data-checked", "false")
                    }
                    else{
                        e.srcElement.setAttribute("data-checked", "true")
                    }

                    let all = document.querySelectorAll(".category-checkbox");
                    let checked = document.querySelectorAll(".category-checkbox[data-checked = 'true']");
                    let unchecked = document.querySelectorAll(".category-checkbox[data-checked = 'false']");

                    if(all.length == checked.length){
                        document.querySelector("#select_all").classList.replace("fa-check-square-o", "fa-check-square")
                    }
                    else{
                        document.querySelector("#select_all").classList.replace("fa-check-square", "fa-check-square-o")
                    }
                }
            }
        )

        document.querySelector("#add_category").onsubmit = (e) => {
            e.preventDefault();
            e.target.classList.add("disabled")

            let name = document.querySelector("[name = 'category_name']");
            let description = document.querySelector("[name = 'category_description']");

            fetch("../assets/php/processes/admin/AddNewCategory.php?name=" + name.value + "&description=" + description.value).then( e => e.json() ).then(
                responseJSON => {
                    // responseJSON = JSON.parse(responseJSON);
                    if(responseJSON.type == "success"){
                        toast(responseJSON.message + " Reloading!", "success", 2000).then(e => window.location.reload());
                    }
                    else{
                        toast(responseJSON.message, "danger");
                    }
                }
            );
        }

        document.querySelector(".add_category").onclick = () => {
            document.querySelector("#add_category_pane").classList.remove("d-none");
        }

        document.querySelector(".delete_category").onclick = () => {
            let category_list = [];

            document.querySelectorAll("input.category-checkbox").forEach(
                each => {
                    if(each.checked == true){
                        category_list.push(each.value);
                    }
                }
            );
            if(category_list.length > 0 && confirm("Do you want to delete categories?")){
                fetch("../assets/php/processes/admin/DeleteCategory.php?category_list=" + JSON.stringify(category_list)).then(e => e.json()).then(
                    responseJSON => {
                        console.log(responseJSON);
                        if(responseJSON.type == "success"){
                            toast(responseJSON.message + " Reloading!", "success", 2000).then(e => window.location.reload());
                        }
                        else{
                            toast(responseJSON.message, "danger");
                        }
                    }
                );
            }
            else if(category_list.length == 0){
                toast("Nothing to delete!");
            }
        }
    }

    select_all_categories(){
        document.querySelectorAll(".category-checkbox").forEach(
            item => {
                item.checked = true;
                item.setAttribute("data-checked", "true");
            }
        );
    }

    deselect_all_categories(){
        document.querySelectorAll(".category-checkbox").forEach(
            item => {
                item.checked = false;
                item.setAttribute("data-checked", "false");
            }
        );
    }
}

var category = new Category();
