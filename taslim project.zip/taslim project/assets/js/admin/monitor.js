class Monitor{
	constructor(){
		document.querySelector("#webcam-activator").addEventListener(
			"click",
			(e) => {
				document.querySelector("#caption-area").classList.replace("text-secondary", "light-green-color");
				document.querySelector("#caption-text").innerText = "started webcam feed";
				e.target.innerText = "webcam feed activated";
				e.target.classList.add("disabled");

				fetch("../assets/php/processes/admin/StartPyModule.php").then(response => response.text()).then(
					responseText => {
						if(responseText === "done"){
							document.querySelector("#caption-area").classList.replace("light-green-color", "text-secondary");
							document.querySelector("#caption-text").innerText = "webcam feed not available";
							e.target.innerText = "activate webcam feed";
							e.target.classList.remove("disabled");
						}
					}
				);
			}
		);

		document.querySelector("#train-dataset").addEventListener(
			"click",
			(e) => {
				e.target.classList.add("disabled");
				e.target.innerHTML = "Training dataset...";

				let timestamp = new Date().getTime();
				let d = new Date(timestamp).getDate();
				let m = Number(new Date(timestamp).getMonth()) + 1;
				let y = new Date(timestamp).getFullYear();
				let h = new Date(timestamp).getHours();
				let i = new Date(timestamp).getMinutes();
				let s = new Date(timestamp).getSeconds();

				let formated_time = d + "/" + m + "/" + y + " " + ((h < 10) ? "0" : "") + h + ":" + ((i < 10) ? "0" : "") + i + ":" + ((s < 10) ? "0" : "") + s;
				console.log(formated_time)

				fetch("../assets/php/processes/admin/TrainDataset.php?timestamp=" + timestamp).then(response => response.text()).then(
					responseText => {
						console.log(responseText)
					}
				);
			}
		);
	}
}

var monitor = new Monitor();
