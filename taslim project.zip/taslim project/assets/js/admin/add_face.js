class AddProduct{
    constructor(){
        document.querySelectorAll("input").forEach(
            item => {
                item.addEventListener(
                    "input",
                    () => {
                        if(document.querySelector("input[name = 'add_face']").classList.contains("disabled")){
                            document.querySelector("input[name = 'add_face']").classList.remove("disabled");
                        }
                    }
                );
            }
        );
        document.querySelector("input[name = 'add_face']").addEventListener(
            "click",
            (e) => {
                let formData = new FormData();
                e.srcElement.classList.add("disabled");
                e.target.value = "Processing...";

                e.srcElement.form.onsubmit = (f) => {
                    f.preventDefault();
                }

                e.srcElement.form.querySelectorAll("input").forEach(
                    item => {
                        if(item.type == "file" && item.files.length > 0){
                            console.log(item.files)
                            formData.append(item.name, item.files[0])
                        }
                        else{
                            formData.append(item.name, item.value)
                        }
                    }
                );

                let get_query = e.srcElement.form.action.split("?")[1] || "";
                get_query = ((get_query == "") ? get_query : "?" + get_query);

                let xmlHtttp = new XMLHttpRequest();
                xmlHtttp.onreadystatechange = function(){
                    if(xmlHtttp.readyState == 4 && xmlHtttp.status == 200){
                        console.log(xmlHtttp.responseText);
                        try{
                            let responseText = JSON.parse(xmlHtttp.responseText);
                            (
                                (responseText.type == "error")
                                ? e.srcElement.classList.remove("disabled")
                                : e.srcElement.classList.add("disabled")
                            );
                            toast(responseText.message, ((responseText.type == "error") ? "danger" : "primary"));
                            e.target.value = "Add Face";
                        }
                        catch(e){
                            toast("An error occured", "danger", 5000)
                        }

                    }
                };
                xmlHtttp.open(
                    "POST",
                    "../assets/php/processes/admin/AddNewFace.php" + get_query,
                    true
                );
                xmlHtttp.send(formData);
            }
        );

        document.querySelector("input[name = 'face_img']").oninput = (e) => {
            var reader = new FileReader();
            reader.onload = () => {
                var dataURL = reader.result;
                var output = document.querySelector("#preview_img");
                output.src =
                    dataURL;
            }
            if(e.srcElement.files[0] != undefined){
                reader.readAsDataURL(e.srcElement.files[0]);
            }
        }
    }
}

var addProduct = new AddProduct();
