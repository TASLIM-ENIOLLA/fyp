try{

    class AllEmployees{
        constructor(){
            this.employee_list_JSON = window.employee_list_JSON;

            document.querySelector("#search").addEventListener(
                "click",
                this.make_search
            );

            [document.querySelector("#search_query"), document.querySelector("#search_category")].forEach(
                item => {
                    item.addEventListener(
                        "input",
                        this.make_search
                    );
                }
            );
        }

        make_search = () => {
            let search_query = document.querySelector("#search_query").value.toString().toLowerCase();
            let search_category = document.querySelector("#search_category").value;

            if(search_query.length < 1){
                let employee_list_JSON = this.employee_list_JSON;

                document.querySelector("#record-returned").innerHTML = employee_list_JSON.length;

                document.querySelectorAll("#employee-list > div").forEach(
                    item => {
                        item.remove();
                    }
                );

                for(let employee in employee_list_JSON){
                    if(employee == 0 || Number(employee)){
                        employee = employee_list_JSON[employee];
                        document.querySelector("#employee-list").appendChild(employee);
                    }
                }
            }
            else{
                let search_result = [];
                this.employee_list_JSON.forEach(
                    item => {
                        let search_string = item.dataset[search_category].toString().toLowerCase();

                        if(new RegExp(search_query).test(search_string)){
                            search_result.push(item);
                        }
                    }
                );

                document.querySelector("#record-returned").innerHTML = search_result.length;

                document.querySelectorAll("#employee-list > div").forEach(
                    item => {
                        item.remove();
                    }
                );

                if(search_result.length > 0){
                    search_result.forEach(
                        item => {
                            document.querySelector("#employee-list").appendChild(item);
                        }
                    );
                }
                else{
                    let item = document.createElement("div");
                        item.className = "mt-5 mb-3 p-5 bold text-secondary rounded text-c col-11 mx-auto";
                        item.innerText = "Oops! No employee found.";

                    document.querySelector("#employee-list").appendChild(item);
                }
            }
        }
    }

    new AllEmployees();
}
catch(e){
    console.warn(e)
}
