document.querySelectorAll("input").forEach(
    item => {
        item.addEventListener(
            "input",
            () => {
                document.querySelector("[name = 'edit_profile']").classList.remove("disabled");
            }
        )
    }
);

document.querySelector("#profile_img").addEventListener(
    "change",
    (e) => {
        if(e.srcElement.files[0] != undefined){
            let reader = new FileReader();

            reader.readAsDataURL(e.srcElement.files[0]);
            reader.onload = () => {
                let dataURL = reader.result;
                let output = document.querySelector("#profile_img_preview");

                output.src = dataURL;
            }
        }
    }
);

document.querySelector("[name = 'edit_profile']").addEventListener(
    "click",
    (e) => {
        e.srcElement.form.onsubmit = (f) => {
            f.preventDefault();
        }
        frostedDialog.prompt({
            promptText: "Enter current password to effect change.",
            type: "password",
            placeholdText: "Enter password here..."
        }).then(
            currentPassword => {
                let formData = new FormData();
                let a = document.createElement("input");
                a.type = "hidden";
                a.value = currentPassword || "";
                a.name = "current_password";
                e.srcElement.form.appendChild(a);

                e.srcElement.form.querySelectorAll("input").forEach(
                    item => {
                        if(item.type == "file" && item.files.length > 0){
                            formData.append(item.name, item.files[0])
                        }
                        else{
                            formData.append(item.name, item.value)
                        }
                    }
                );

                let xmlHtttp = new XMLHttpRequest();
                xmlHtttp.onreadystatechange = function(){
                    if(this.readyState == 4 && this.status == 200){
                        let responseText = JSON.parse(this.responseText);
                        toast(responseText.message, ((responseText.type == "error") ? "danger" : "primary"));
                    }
                };
                xmlHtttp.open(
                    "POST",
                    "../assets/php/processes/admin/UpdateAdminData.php",
                    true
                );
                xmlHtttp.send(formData);
            }
        );
    }
);
