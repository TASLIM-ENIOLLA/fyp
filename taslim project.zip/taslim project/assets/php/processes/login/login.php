<?php

    include "../../init.php";

    if(isset($_POST["login_credentials"]) && !empty($_POST["login_credentials"])){
        $login_credentials = json_decode($_POST["login_credentials"]);

        $sql_query = "SELECT * FROM admin WHERE email = '" . $login_credentials -> email . "' AND password = '" . md5($login_credentials -> password) . "'";
        $query = $connect -> query($sql_query);

        if($query -> num_rows > 0){
            $row = $query -> fetch_assoc();
            setcookie(
                "ACS",
                json_encode(
                    array(
                        "id" => $row['id'],
                        "email" => $login_credentials -> email,
                        "f_name" => $row['f_name'],
                        "user" => "admin",
                        "last_dataset_training_timestamp" => NULL
                    )
                ),
                (time() + (365 * 3600)),
                "/"
            );
            echo "admin";
        }
        else{
            echo "failed";
        }
    }
    else{
        echo "error";
    }

?>
