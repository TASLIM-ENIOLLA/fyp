<?php

    class LoadAdminData{
        public function __construct(){
            global $connect;

            $admin_id = json_decode($_COOKIE["ACS"]) -> id;

            $query = $connect -> query(
                "SELECT * FROM admin WHERE id = '$admin_id'"
            );

            if($query == TRUE){
                define(
                    "ADMIN",
                    $query -> fetch_assoc()
                );
            }
        }
        public function validate_profile_img($img_src){
            if(file_exists("../assets/" . $img_src)){
                return "../assets/" . $img_src;
            }
            else{
                return "../assets/img/user_default.png";
            }
        }
    }

    $LoadAdminData = new LoadAdminData();

?>
