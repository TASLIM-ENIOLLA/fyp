<?php

    include "Shell_Exec.php";

    $e = $Shell_Exec -> exec_multi_cmds_sequentially(
        "cd ../../../py",
        "python read_media.py"
    );

    echo "done";

?>
