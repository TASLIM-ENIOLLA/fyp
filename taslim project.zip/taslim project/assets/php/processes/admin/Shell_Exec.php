<?php

    class Shell_Exec{
        public function __construct(){

        }
        public function exec_multi_cmds(...$cmds){
            $command = "";

            foreach ($cmds as $key => $index) {
                $command .= $index;
                if($key != count($cmds) - 1){
                    $command .= ' & ';
                }
            }

            exec($command, $output, $status);

            return array(
                "command" => $command,
                "output" => $output,
                "status" => $status
            );
        }
        public function exec_multi_cmds_sequentially(...$cmds){
            $command = "";

            foreach ($cmds as $key => $index) {
                $command .= $index;
                if($key != count($cmds) - 1){
                    $command .= ' && ';
                }
            }

            exec($command, $output, $status);

            return array(
                "command" => $command,
                "output" => $output,
                "status" => $status
            );
        }
    }

    $Shell_Exec = new Shell_Exec();

?>
