<?php

    include "../../init.php";

    class DeleteFaces{
        public function __construct(){
            global $connect;
            $emp_IDs = $_POST["employee"];
            $list = "";

            foreach ($emp_IDs as $index => $emp_ID){
                $list .= "'" . $emp_ID . "'";

                if($index < count($emp_IDs) - 1){
                    $list .= ", ";
                }
            }

            $query = $connect -> query(
                "DELETE FROM faces_and_images WHERE emp_ID IN ($list)"
            );

            if($query){
                echo "success";
            }
            else{
                echo "error";
            }
        }
    }

    $DeleteFaces = new DeleteFaces();

?>
