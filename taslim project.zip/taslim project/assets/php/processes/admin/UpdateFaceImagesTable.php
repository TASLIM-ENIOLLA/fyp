<?php

    class UpdateFaceImagesTable{
        public function __construct(){
            global $connect;
            global $Generic;

            $FOLDERS = $this -> getFolders();
            $TABLE_ROWS = [];

            $query = $connect -> query(
                "SELECT * FROM faces_and_images"
            );

            if($query && $query -> num_rows > 0){
                while($rows = $query -> fetch_assoc()){
                    array_push($TABLE_ROWS, $rows["emp_ID"]);
                }
            }

            $FOLDER_AND_ROW_DIFF = array_diff($FOLDERS, $TABLE_ROWS);

            foreach($FOLDER_AND_ROW_DIFF as $FOLDER){
                $id = $Generic -> face_and_image_id_gen();
                $query = $connect -> query(
                    "INSERT INTO faces_and_images SET id = '$id', emp_ID = '$FOLDER', face_image = '$FOLDER/'"
                );
            }
        }
        private function getFolders(){
            $DIR = "../assets/img/employee/faces/";
            $DIR_FOLDERS = scandir($DIR);
            $FOLDER_ARRAY = [];

            foreach($DIR_FOLDERS as $FOLDER){
                if($FOLDER != "." && $FOLDER != ".."){
                    array_push($FOLDER_ARRAY, $FOLDER);
                }
            }

            return $FOLDER_ARRAY;

            /*
            $list .= "'" . $product_ids[$product_id] . "'";

            if($product_id < count($product_ids) - 1){
                $list .= ", ";
            }
            foreach ($product_ids as $product_id => $key){

            }
            */
        }
    }

    $UpdateFaceImagesTable = new UpdateFaceImagesTable();

?>
