<?php
    class LoadAccessLog{
        public $row_length = 0;
        public function __construct(){
            global $connect;

            $query = $connect -> query(
                "SELECT `access_log`.`id`, `access_log`.`emp_ID`, `access_log`.`timestamp`, `employee`.`f_name`, `employee`.`l_name`, `employee`.`department_ID`, `employee`.`profile_img` FROM access_log LEFT JOIN employee ON `access_log`.`emp_ID` = `employee`.`emp_ID` ORDER BY `access_log`.`timestamp` DESC"
            );

            $this -> row_length = $query -> num_rows;
            $this -> query = $query;
        }
        public function render(){

            if($this -> row_length > 0){
                $rows = 0;
                $res = '
                    <div class = "col-12">
                        <div class = "pb-2 bold">
                            Retrieved
                            <span id = "record-returned">' . $this -> row_length . '</span> out of <span id = "record-total">' . $this -> row_length . '</span>
                            record(s)
                        </div>
                        <div class = "border rounded-lg bg-white shadow flex-h j-c-c a-i-c mb-3">
                            <input type = "search" id = "search_query" class = "flex-1 border-0 py-2 px-3 outline-0" placeholder = "Type keyword..."/>
                            <div class = "p-2 my-1 border-left">
                                <span>Search by: </span>
                                <select id = "search_category" class = "border p-2 text-secondary outline-0 rounded bold text-capitalize">
                                    <option value = "name" selected>name</option>
                                    <option value = "department">department</option>
                                </select>
                            </div>
                            <span title = "Make search" id = "search" class = "fa fa-search pl-3 pr-4 h-100 theme-color flicker cursor-pointer" style = "font-size: 1.5rem;"></span>
                        </div>
                    </div>
                    <div id = "employee-list" class = "flex-1 col-12 overflow-y-auto">
                ';
                while($row = $this -> query -> fetch_assoc()){
                    $row["profile_img"] = (
                        ($row["profile_img"] == null)
                        ? "../assets/img/user_default.png"
                        : (
                            (file_exists("../assets/img/employee/faces/" . $row["emp_ID"] . "/" . $row["profile_img"]))
                            ? "../assets/img/employee/faces/" . $row["emp_ID"] . "/" . $row["profile_img"]
                            : "../assets/img/user_default.png"
                        )
                    );
                    $res .= '
                        <div
                            class="border-bottom animated fadeIn p-3 mb-3 flex-h cursor-pointer flicker transit" style="animation-delay: 0.1s;" data-id = "' . $row["id"] . '" data-name = "' . $row["f_name"] . " " . $row["l_name"] . '" data-department = "' . $row["department_ID"] . '">
                            <!-- <div class = "pr-3">
                                <input class = "border" type = "checkbox" name="' . $row["id"] . '" id="' . $row["id"] . '" value = "' . $row["id"] . '" />
                            </div> -->
                            <div class = "flex-1 flex-h a-i-c">
                                <a href = "view_employee_data.php?emp_ID=' . $row["emp_ID"] . '">
                                    <div class="border shadow" style="width: 60px; height: 60px; border-radius: 50%; background: url(' . $row["profile_img"] . ') center center / cover, lightgrey;"></div>
                                </a>
                                <label for = "' . $rows . '" class="flex-1 pl-3">
                                    <div class="w-100 flex-h">
                                        <div class="flex-1 flex-h">
                                            <span class="text-capitalize text-dark flex-1 single-line expandables">
                                                <span class="bold">' . $row["f_name"] . " " . $row["l_name"] . '</span> | <span>' . $row["department_ID"] . '</span>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="w-100 flex-h">
                                        <span class="text-capitalize bold text-success flex-1 expandables">time signature: ' . date("M d, Y. H:i:s", strtotime($row["timestamp"])) . '</span>
                                    </div>
                                </label>
                            </div>
                        </div>
                    ';

                    $rows++;
                }
                $res .= "
                    </div>
                    <script>
                        var employee_list_JSON = document.querySelectorAll('#employee-list > div');
                    </script>
                ";
                return $res;
            }
            else{
                return '
                    <div class = "w-100">
                        <div class = "p-2 my-5 text-secondary mx-auto col-12 rounded text-c bold">
                            Access log is empty!
                        </div>
                    </div>
                ';
            }
        }
    }

    $LoadAccessLog = new LoadAccessLog();
?>
