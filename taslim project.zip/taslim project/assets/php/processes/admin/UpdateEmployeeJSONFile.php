<?php

    $query = $connect -> query(
        "SELECT * FROM employee"
    );

    if($query){
        $res = [];

        while($rows = $query -> fetch_assoc()){
            $obj = array(
                "ID" => $rows["emp_ID"],
                "f_name" => $rows["f_name"],
                "l_name" => $rows["l_name"],
                "email_address" => $rows["email_address"],
                "phone" => $rows["phone"],
                "department" => $rows["department_ID"],
                "emp_image" => $rows["profile_img"],
                "timestamp" => $rows["timestamp"]
            );

            array_push($res, $obj);
        }

        $res = json_encode($res);

        function indent($r){
            $re = "\n";
            for($x = 0; $x <= $r; $x++){
                $re .= "\t";
            }
            return $re;
        }

        $path = "../assets/json/employee.json";
        $indent = 0;

        $res = str_ireplace("{", indent($indent) . "{\n\t\t",$res,$i);
        if($i > 0){
            $indent++;
        }

        $res = str_ireplace("\",", "\"," . indent($indent),$res,$i);
        if($i > 0){
            $indent++;
        }

        if($i > 0){
            $indent -= 2;
        }
        $res = str_ireplace("}", indent($indent) . "}" ,$res,$i);

        if($i > 0){
            $indent -= 2;
        }
        $res = str_ireplace("]", indent($indent) . "]" ,$res,$i);

        file_put_contents($path, $res);
    }

?>
