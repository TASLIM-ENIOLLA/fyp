<?php

    if(isset($_POST["logout"])){
        setcookie(
            "ACS",
            null,
            (time() - (365 * 3600)),
            "/"
        );
        header("Location: ../login");
    }
    elseif(isset($_POST["cancel"])){
        header("Location: index.php");
    }

?>
