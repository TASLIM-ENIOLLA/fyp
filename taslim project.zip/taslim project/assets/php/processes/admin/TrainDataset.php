<?php

    include "Shell_Exec.php";

    $cookie = json_decode($_COOKIE["ACS"]);
    $timestamp = $_GET["timestamp"];

    setcookie(
        "ACS",
        json_encode(
            array(
                "id" => $cookie -> id,
                "email" => $cookie -> email,
                "f_name" => $cookie -> f_name,
                "user" => $cookie -> user,
                "last_dataset_training_timestamp" => $timestamp
            )
        ),
        (time() + (365 * 3600)),
        "/"
    );

    $e = $Shell_Exec -> exec_multi_cmds_sequentially(
        "cd ../../../py",
        "python train_dataset.py"
    )["output"];

    echo $e[0];

?>
