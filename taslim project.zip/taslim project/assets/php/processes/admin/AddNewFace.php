<?php
    include '../../init.php';
    include 'FindFaceInImage.php';

    class ValidateNewProduct{
        public function __construct(){
            if(isset($_POST) && !empty($_POST)){
                global $connect;
                global $Generic;

                $this -> new_face = array(
                    "action" => (isset($_GET["action"]) && $_GET["action"] === "edit_face_data")
                        ? "edit_action"
                        : NULL,
                    "emp_ID" => (isset($_GET["emp_ID"]))
                        ? $_GET["emp_ID"]
                        : isset($_POST["emp_ID"])
                            ? $_POST["emp_ID"]
                            : $Generic -> emp_id_gen(),
                    "face_img" => (isset($_FILES["face_img"]))
                        ? $_FILES["face_img"]
                        : NULL
                );

                $this -> validate_face_data();
            }
        }

        public function validate_face_data(){
            global $Generic;
            global $connect;

            $Generic -> clear_folder("../../../img/tmp/");

            $response = array(
                "type" => "error",
                "new_location" => NULL,
                "message" => "An error occured!"
            );

            $emp_ID = $this -> new_face["emp_ID"];
            $face_img = $this -> new_face["face_img"];
            $employee = $Generic -> verify_emp_ID($emp_ID);
            $employee_existence_on_FAI_table = $Generic -> find_emp_ID_on_FAI_table($emp_ID);

            if($face_img == NULL){
                $response["message"] = "Please select an image.";
            }
            elseif(strlen($emp_ID) > 20){
                $response["message"] = "Employee ID too long (Max. 20 characters).";
            }
            elseif($employee == false){
                $response["message"] = "Employee ID not recognized.";
            }
            else{
                if($face_img != NULL){
                    $ext_arr = [
                        "jpeg",
                        "jpg",
                        "png",
                        "gif"
                    ];
                    $rr = explode(".", $face_img["name"]);
                    $ext = strtolower(end($rr));
                    $new_location = $emp_ID . "/";

                    if(!file_exists("../../../img/employee/faces/" . $new_location)){
                        mkdir("../../../img/employee/faces/" . $new_location, 0777, true);
                    }

                    if(!is_file($face_img["tmp_name"])){
                        $response["message"] = "Image is not a regular file.";
                    }
                    elseif(!array_search($ext, $ext_arr)){
                        $response["message"] = "Image format is not supported.";

                        // if(!file_exists("../../../img/employee/")){
                        //     mkdir("../../../img/employee/");
                        // }
                    }
                    else{
                        if(!copy($face_img["tmp_name"], "../../../img/tmp/" . $face_img["name"])){
                            $response["message"] = "Image upload failed.";
                        }
                        else{
                            $find_face = read_image_in_tmp_folder_for_a_face();

                            if($find_face["no_of_faces"] < 1){
                                $response["message"] = "Couldn't find a face in the image. Try again with a better or another image.";
                            }
                            elseif(!move_uploaded_file(
                                $face_img["tmp_name"],
                                "../../../img/employee/faces/" . $new_location . $face_img["name"]
                            )){
                                $response["message"] = "Image upload failed.";
                            }
                            else{
                                $Generic -> clear_folder("../../../img/tmp/");
                                $response["new_location"] = $new_location;
                                if($this -> new_face["action"] == NULL){
                                    $id = $Generic -> face_and_image_id_gen();
                                    $face_image = $response["new_location"];

                                    if($employee_existence_on_FAI_table == false){
                                        $query = $connect -> query(
                                            "INSERT INTO `faces_and_images` SET `id` = '$id', `emp_ID` = '$emp_ID', `face_image` = '$face_image'"
                                        );

                                        if($query){
                                            $response["type"] = "success";
                                            $response["message"] = "New face added successfully.";
                                        }
                                        else{
                                            $response["type"] = "error";
                                            $response["message"] = "Something went wrong! " . $face_image;
                                        }
                                    }
                                    else{
                                        $response["type"] = "success";
                                        $response["message"] = "New face added successfully.";
                                    }
                                }
                                else{
                                    $face_image = $response["new_location"];

                                    $query = $connect -> query(
                                        "UPDATE `faces_and_images` SET face_image = '$face_image' WHERE `emp_ID` = '$emp_ID'"
                                    );

                                    if($query){
                                        $response["type"] = "success";
                                        $response["message"] = "New face added successfully.";
                                    }
                                    else{
                                        $response["type"] = "error";
                                        $response["message"] = "Something went wrong!";
                                    }
                                }
                            }
                        }
                    }
                }
                else{
                    if($this -> new_face["action"] == NULL){
                        $id = $Generic -> face_and_image_id_gen();
                        $face_image = $response["new_location"];

                        $query = $connect -> query(
                            "INSERT INTO `faces_and_images` SET id = '$id', `emp_ID` = '$emp_ID', face_image = '$face_image'"
                        );

                        if($query){
                            $response["type"] = "success";
                            $response["message"] = "New face added successfully.";
                        }
                        else{
                            $response["type"] = "error";
                            $response["message"] = "Something went wrong!";
                        }
                    }
                    else{
                        $face_image = $response["new_location"];

                        $query = $connect -> query(
                            "UPDATE `faces_and_images` SET face_image = '$face_image' WHERE `emp_ID` = '$emp_ID'"
                        );

                        if($query){
                            $response["type"] = "success";
                            $response["message"] = "New face added successfully.";
                        }
                        else{
                            $response["type"] = "error";
                            $response["message"] = "Something went wrong!";
                        }
                    }
                }
            }

            $this -> response(
                $response["type"],
                $response["message"]
            );
        }

        public function on_success(){
            if(isset($_SESSION["message"])){
                $message = $_SESSION["message"];
                $_SESSION["message"] = NULL;

                return $this -> response("success", $message);
            }
        }

        private function response($type, $message){
            echo json_encode(
                array(
                    "type" => $type,
                    "message" => $message
                )
            );
        }

        public function format_date($date, $format){
            if(date_create($date)){
                return date_format(date_create($date), $format);
            }
            else{
                return "";
            }
        }

        public function is_set($var){
            return ((isset($var)) ? $var : "");
        }

        public function validate_image($img_src){
            if(file_exists($img_src)){
                return $img_src;
            }
            else{
                return "../assets/img/corrupt_img.png";
            }
        }
    }

    $ValidateNewProduct = new ValidateNewProduct();

?>
