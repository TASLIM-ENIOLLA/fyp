<?php

    class LoadEmployeeData{
        function __construct(){
            global $connect;

            if(isset($_GET["emp_ID"])){
                $this -> emp_ID = $emp_ID = $_GET["emp_ID"];

                $query = $connect -> query(
                    "SELECT * FROM employee WHERE emp_ID = '$emp_ID'"
                );

                if($query && $query -> num_rows > 0){
                    $this -> employee_data = $query -> fetch_assoc();
                    $this -> employee_data["emp_image"] = (($this -> employee_data["emp_image"] == NULL) ? "default.png" : $this -> employee_data["emp_image"]);
                    // $this -> employee_data["image"] = $this -> employee_data["emp_ID"] . "/";
                    $this -> display_employee_data();
                }
                else{
                    $this -> employee_data = null;
                    $this -> employee_not_found();
                }
            }
        }

        public function display_employee_data(){
            if($this -> employee_data != null){
                return '
                    <div class = "bg-white shadow-sm p-4 border-radius-20px">
                        <div class = "flex-h flex-1 h-100 flex-wrap pt-3">
                            <div class = "col-12">
                                <div class = "p-3 rounded-lg mb-4 border flex-v j-c-c a-i-c">
                                    <img id = "profile_img_preview" src = "' . ((file_exists("../assets/img/employee/" . $this -> employee_data["emp_image"])) ? "../assets/img/employee/" . $this -> employee_data["emp_image"] : "../assets/img/user_default.png") . '" class="d-block border shadow-sm p-0 rounded-lg mx-auto col-10" style = "max-width: 280px;"/>
                                </div>
                            </div>
                            <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                                <span class = "bold">First name</span>
                                <input readonly value = "' . $this -> employee_data["f_name"] . '" type = "text" class = "text-capitalize p-3 border my-2 rounded d-block w-100 outline-0" />
                            </div>
                            <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                                <span class = "bold">Last name</span>
                                <input readonly value = "' . $this -> employee_data["l_name"] . '" type = "text" class = "text-capitalize p-3 border my-2 rounded d-block w-100 outline-0" />
                            </div>
                            <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                                <span class = "bold">Email address</span>
                                <input readonly value = "' . $this -> employee_data["email_address"] . '" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0" />
                            </div>
                            <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                                <span class = "bold">Phone number</span>
                                <input readonly value = "' . $this -> employee_data["phone"] . '" type = "phone" class = "text-capitalize p-3 border my-2 rounded d-block w-100 outline-0" />
                            </div>
                            <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                                <span class = "bold">Department</span>
                                <input readonly value = "' . $this -> employee_data["department_ID"] . '" type = "text" class = "text-capitalize p-3 border my-2 rounded d-block w-100 outline-0" />
                            </div>
                        </div>
                    </div>
                ';
            }
            else{
                return '
                    <div class = "p-5 bg-light shadow-sm text-c rounded-lg text-muted bold">
                        This product was not found on the database!
                    </div>
                ';
            }
        }

        public function product_not_found(){
            return '
                <div class = "bg-light p-5 text-secondary bold text-c shadow-sm">

                </div>
            ';
        }
    }

    $LoadEmployeeData = new LoadEmployeeData();

?>
