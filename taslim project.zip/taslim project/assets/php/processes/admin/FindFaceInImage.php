<?php

    include "Shell_Exec.php";

    function read_image_in_tmp_folder_for_a_face(){
        global $Shell_Exec;

        $e = $Shell_Exec -> exec_multi_cmds_sequentially(
            "cd ../../../py",
            "python find_face_in_image.py"
        )["output"];

        if(count($e) > 0){
            return array(
                "no_of_faces" => $e[0]
            );
        }
        else{
            return array(
                "no_of_faces" => 0
            );
        }
    }

?>
