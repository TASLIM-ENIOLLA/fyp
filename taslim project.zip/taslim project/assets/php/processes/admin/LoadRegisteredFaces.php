 <?php

    class LoadRegisteredFaces{
        public $row_length = 0;
        public function __construct(){
            global $connect;

            $query = $connect -> query(
                "SELECT faces_and_images.*, employee.f_name, employee.l_name FROM faces_and_images INNER JOIN employee ON faces_and_images.emp_ID = employee.emp_ID"
            );

            if($query && $query -> num_rows > 0){
                $this -> row_length = $query -> num_rows;
                $this -> query = $query;
            }
        }
        public function render(){
            $res = '
                <div class = "features">
            ';

            while($rows = $this -> query -> fetch_assoc()){
                $rows["face_image"] = (
                    (!empty($rows["face_image"]))
                    ? (
                        (file_exists("../assets/img/employee/" . $rows["face_image"]))
                        ? "../assets/img/employee/" . $rows["face_image"]
                        : "../assets/img/user_default.png"
                    )
                    : "../assets/img/user_default.png"
                );
                $res .= '
                    <a href = "?emp_ID=' . $rows["emp_ID"] . '" style = "min-height: 180px;" class = "rounded-lg po-rel shadow border">
                        <div
                            class = "h-100 w-100"
                            style = "background-image: url(' . $rows["face_image"] . '); background-size: cover; background-position: center;"></div>
                        <div class = "po-abs top-100 translate-Y--100 w-100 bg-black-faded p-3 flex-h">
                            <span class = "flex-1 single-line bold text-white">' . $rows["f_name"] . " " . $rows["l_name"] . '</span>
                        </div>
                        <input type = "checkbox" name = "employee[]" value = "' . $rows["emp_ID"] . '" class = "modify-action po-abs top-0 left-0 m-2" style = "transform: scale(1.2);" />
                    </a>
                ';
            }

            $res .= '
                </div>
            ';

            return $res;
        }

        public function load_employee_data(){
            global $connect;
            $emp_ID = $_GET["emp_ID"];

            $query = $connect -> query(
                "SELECT faces_and_images.*, employee.* FROM faces_and_images INNER JOIN employee ON faces_and_images.emp_ID = employee.emp_ID WHERE faces_and_images.emp_ID = '$emp_ID'"
            );

            if($query && $query -> num_rows > 0){
                $row = $query -> fetch_assoc();
                return '
                    <div class = "flex-h flex-wrap">
                        <div class = "col-12">
                            <div class = "pointer-events-0 rounded-lg mb-4 flex-v j-c-c a-i-">
                                <img id = "profile_img_preview" src = "' . $this -> validate_employee_img($row["profile_img"]) . '" class="d-block border shadow-sm p-0 rounded-lg mx-aut col-10" style = "max-width: 280px;"/>
                            </div>
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">First name</span>
                            <input readonly value = "' . $row["f_name"] . '" name = "f_name" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0 disable" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Last name</span>
                            <input readonly value = "' . $row["l_name"] . '" name = "l_name" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0 disable" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Mobile number</span>
                            <input readonly value = "' . $row["phone"] . '" name = "phone" placeholder = "0xxx xxx xxxx" type = "text" class = "p-3 border my-2 rounded d-block w-100 outline-0 disable" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Email address</span>
                            <input readonly value = "' . $row["email_address"] . '" name = "email_address" type = "email" class = "p-3 border my-2 rounded d-block w-100 outline-0 disable" />
                        </div>
                        <div class = "col-12 col-sm-6 col-lg-6 mb-3">
                            <span class = "bold">Department</span>
                            <input readonly value = "' . $row["department_ID"] . '" name = "department" type = "text" class = "p-3 border my-2 rounded d-block text-capitalize w-100 outline-0 disable" />
                        </div>
                        <!-- <div class = "my-3 p-3 col-12">
                            <input readonly type = "submit" name = "edit_profile" class = "p-3 transit disabled d-block w-100 theme-bg border-0 rounded shadow text-c bold text-white" value = "Save Changes"/>
                        </div> -->
                    </div>
                ';
            }
        }

        private function validate_employee_img($img){
            $DIR = "../assets/img/employee/profile/";
            if(file_exists($DIR . $img)){
                return $DIR . $img;
            }
            else{
                return "../assets/img/user_default.png";
            }
        }
    }

    $LoadRegisteredFaces = new LoadRegisteredFaces();

?>
