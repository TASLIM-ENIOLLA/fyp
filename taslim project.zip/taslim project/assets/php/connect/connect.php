<?php

    $connect = new mysqli(
        "localhost",
        "root",
        "",
        "access_control_system"
    );

    if($connect -> connect_error){
        die("Connection failed: " . $connect -> connect_error);
    }

    session_start();

?>
