<?php
    define(
        "APP_NAME",
        "Door Access Control System"
    );
?>
