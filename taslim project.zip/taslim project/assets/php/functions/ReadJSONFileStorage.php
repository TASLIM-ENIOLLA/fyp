<?php

    class ReadJSONFileStorage{
        public function __construct($filepath){
            $JSONFileStorage = fopen($filepath, "r+") or die("Could not read file at " . $filepath);

            $readJSONFileStorage = fread(
                $JSONFileStorage,
                filesize($filepath)
            );

            return $this -> JSONData = $readJSONFileStorage;
        }

        public function getRowByID($id){
            $parsedJSONData = json_decode($this -> JSONData) or die("Failed to parse JSON data.");

            foreach($parsedJSONData as $row){
                if(strtolower($id) === strtolower($row -> ID)){
                    return $row;
                }
            }
        }

        public function getAllRows(){
            $parsedJSONData = json_decode($this -> JSONData) or die("Failed to parse JSON data.");

            return $parsedJSONData;
        }
    }
    $r = new ReadJSONFileStorage("../../json/employee.json");
    print_r($r -> getRowByID("emp-002"));

?>
