<?php

    try{
        class Generic{
            function __construct($arg = false){
                if($arg == true){
                    echo "Generic class has been called";
                }
            }
            public function filterInput($var){
                global $connect;
                $var = trim($var);
                $var = htmlspecialchars($var);
                $var = stripslashes($var);
                $var = strip_tags($var);
                $var = mysqli_real_escape_string($connect, $var);
                // $var = strtolower($var);
                return $var;
            }
            public function filterInput2($var){
                global $connect;
                $var = trim($var);
                $var = htmlspecialchars($var);
                $var = stripslashes($var);
                $var = strip_tags($var);
                // $var = mysqli_real_escape_string($connect, $var);
                // $var = strtolower($var);
                return $var;
            }
            public function forbiddenChars($string, $type = null){
                if($type == "name" || $type == null){
                    return preg_match("/[^0-9a-zA-Z_\-\s]/", $string);
                }
        		elseif($type == "text"){
                    return preg_match("/[^0-9a-zA-Z_\/\r\s\-\+\,\!\.]/", $string);
                }
        		elseif($type == "number"){
                    return preg_match("/[^0-9\,\.]/", $string);
                }
                elseif($type == "password"){
                    return preg_match("/[^0-9a-zA-Z_]/", $string);
                }
            }
            public function clear_folder($path){
                foreach(scandir($path) as $file){
                    if($file != "." && $file != ".."){
                        unlink($path . $file);
                    }
                }
            }
            public function randomTextGen($no_of_chars){
                $rr = '';
                for($x = 0; strlen($rr) < $no_of_chars; $x++){
                    $re = mt_rand(48, 90);
                    if($re < 58 || $re > 64){
                        $re = dechex($re);
                        $re = pack("H*", $re);
                        $rr .= $re;
                    }
                }
                // $rr = strtolower($rr);
                return $rr;
            }
            public function face_and_image_id_gen(){
                global $connect;

                $a = "fi-id-" . strtolower($this -> randomTextGen(14));
                $q = $connect -> query("SELECT * FROM faces_and_images WHERE id = '$a'");

                if($q -> num_rows > 0){
                    $this -> face_and_image_id_gen();
                }
                else{
                    return $a;
                }
            }
            public function emp_id_gen(){
                global $connect;

                $a = "emp-" . strtolower($this -> randomTextGen(16));
                $q = $connect -> query("SELECT * FROM employee WHERE id = '$a'");

                if($q -> num_rows > 0){
                    $this -> emp_id_gen();
                }
                else{
                    return $a;
                }
            }
            public function verify_emp_ID($emp_ID){
                global $connect;

                $query = $connect -> query("SELECT * FROM employee WHERE `emp_ID` = '$emp_ID'");

                if($query && $query -> num_rows > 0){
                    return $query -> fetch_assoc();
                }
                else{
                    return false;
                }
            }
            public function find_emp_ID_on_FAI_table($emp_ID){
                global $connect;

                $query = $connect -> query("SELECT * FROM `faces_and_images` WHERE `emp_ID` = '$emp_ID'");

                if($query && $query -> num_rows > 0){
                    return $query -> fetch_assoc();
                }
                else{
                    return false;
                }
            }
        }

        $Generic = new Generic();
    }
    catch(Exception $e){
        die("Couldn't compile generic class: " . $e);
    }

?>
