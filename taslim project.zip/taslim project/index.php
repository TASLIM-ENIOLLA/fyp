<?php

    if(isset($_COOKIE['ACS'])){
        header('Location: admin/');
    }
    else{
        header('Location: login/');
    }

?>
